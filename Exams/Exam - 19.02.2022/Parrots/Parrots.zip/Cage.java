package Examp.exam19_02_2022.Parrots;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Cage {
    private String name;
    private int capacity;
    private List<Parrot> data;

    public Cage(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        data = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public void add(Parrot parrot) {
        if (this.data.size() < this.capacity) {
            data.add(parrot);
        }
    }

    public boolean remove(String name) {
        return data.removeIf((e -> e.getName().equals(name)));
    }

    public Parrot sellParrot(String name) {
        Parrot parrot = this.data.stream()
                .filter(s -> s.getName().equals(name))
                .findAny()
                .orElse(null);
        if (parrot != null) {
            parrot.setAvailable(false);
        }
        return parrot;
    }

    public List<Parrot> sellParrotBySpecies(String species) {
        List<Parrot> parrots = new ArrayList<>();
        this.data.stream().filter(s -> s.getSpecies().equals(species)).forEach(s -> {
            parrots.add(s);
            s.setAvailable(false);
        });
        return parrots;
    }

    public int count() {
        return data.size();
    }

    public String report() {
        return "Parrots available at " + this.name + ":" + System.lineSeparator() +
                this.data.stream().filter(Parrot::isAvailable)
                        .map(Parrot::toString)
                        .collect(Collectors.joining(System.lineSeparator()));
    }

}
